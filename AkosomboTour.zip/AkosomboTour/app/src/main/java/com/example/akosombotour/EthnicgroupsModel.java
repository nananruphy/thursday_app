package com.example.akosombotour;

import java.util.ArrayList;

public class EthnicgroupsModel {
    private String history;
    public EthnicgroupsModel(String history) {
        this.history = history;
    }
    public String getHistory(){
        return history;
    }
    public static ArrayList<EthnicgroupsModel> getUsers() {
        ArrayList<EthnicgroupsModel> history = new ArrayList<EthnicgroupsModel>();
        history.add(new EthnicgroupsModel("ETHNIC GROUPS"));
        history.add(new EthnicgroupsModel("Ewe 45.8%"));
        history.add(new EthnicgroupsModel("Adangbe (28.1%)"));
        history.add(new EthnicgroupsModel("Akan (11.6%)"));
        history.add(new EthnicgroupsModel("RELIGION"));
        history.add(new EthnicgroupsModel("Christianity (89%)"));
        history.add(new EthnicgroupsModel("Islamic (3.7%)"));
        history.add(new EthnicgroupsModel("Traditionalist (2.4%)"));
        return history;
    }
}
