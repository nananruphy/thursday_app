package com.example.akosombotour;
import java.util.ArrayList;
public class HotelsModel {
    private String history;
    public HotelsModel(String history) {
        this.history = history;
    }
    public String getHistory(){
        return history;
    }
    public static ArrayList<HotelsModel > getUsers() {
        ArrayList<HotelsModel > history = new ArrayList<HotelsModel >();
        history.add(new HotelsModel ("The Royal Senchi"));
        history.add(new HotelsModel ("Zito Guest House"));
        history.add(new HotelsModel ("Santa Monica Home Lodge)"));
        history.add(new HotelsModel ("BB Tributary Hotel"));
        history.add(new HotelsModel ("3A's Guest House"));
        history.add(new HotelsModel ("Volta Hotel"));
        history.add(new HotelsModel ("Maveline Hotel"));
        return history;
    }
}
