package com.example.akosombotour;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class HotelsAdapter extends ArrayAdapter<HotelsModel> {
    public HotelsAdapter (Context context, ArrayList<HotelsModel> historyad) {
        super(context, 0, historyad);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        HotelsModel historyad = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.hotels, parent, false);
        }
        // Lookup view for data population
        TextView tvHistory = (TextView) convertView.findViewById(R.id.tvHotels);
        // Populate the data into the template view using the data object
        tvHistory.setText(historyad.getHistory());
        // Return the completed view to render on screen
        return convertView;
    }
}

